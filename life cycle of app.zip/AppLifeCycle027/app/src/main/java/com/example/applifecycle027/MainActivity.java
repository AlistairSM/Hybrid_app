package com.example.applifecycle027;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.d("Lifecycle1", "onCreate: Create part Successful");
    }

    @Override
    protected void onStart(){
        super.onStart();
        Log.d("Lifecycle2", "onStart: Start part Successful");
    }

    @Override
    protected void onResume(){
        super.onResume();
        Log.d("Lifecycle3", "onResume: Resume part Successful");
    }

    @Override
    protected void onPause(){
        super.onPause();
        Log.d("Lifecycle4", "onPause: Pause part Successful");
    }

    @Override
    protected void onRestart(){
        super.onRestart();
        Log.d("Lifecycle5", "onRestart: Restart part Successful");
    }

    @Override
    protected void onStop(){
        super.onStop();
        Log.d("Lifecycle6", "onStop: Stop part Successful");
    }

    @Override
    protected void onDestroy(){
        super.onDestroy();
        Log.d("Lifecycle7", "onDestroy: Destroy part Successful");
    }
}